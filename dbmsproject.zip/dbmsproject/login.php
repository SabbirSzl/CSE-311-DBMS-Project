<?php

	session_start();
	if(isset($_POST['login']))
	{
		if(empty($_POST['username']) || empty($_POST['password']))
			{ $error = "Username or Password Is invalid";
			}
	else
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
	$connection = new mysqli("localhost", "root", "", "dbms_project");

	$query = "SELECT nsuid,password FROM userinfo WHERE nsuid = ? AND password = ? LIMIT 1";
	
	$stmt = $connection->prepare($query);
	$stmt->bind_param("is", $username, $password);
	$stmt->execute();
	$stmt->bind_result($username,$password);
	$stmt->store_result();
	if($stmt->fetch())
	{
		$user_name = "SELECT name FROM userinfo WHERE nsuid = '$username'";
		$result = mysqli_query($connection,$user_name);
		$row = mysqli_fetch_row($result);
		$name = $row['name'];
		$_SESSION['login_user'] = $name;
		$login_session = $_SESSION['login_user'];
		header("location: profile.php");
	}
	mysqli_close($connection);
	}
}
?>