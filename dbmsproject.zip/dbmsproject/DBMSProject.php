
<!DOCTYPE html>
<html>
<head>
<title> Sports Person Finder @ NSU </title>
<link rel="stylesheet" type="text/css" href="CSS/Design.css">
</head>
<body>
  <div class="main">
      <div class="logo">
        <img src="logo.png">
      </div>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Friends</a></li>
        <li><a href="#">Slots</a></li>
        <li><a href="#">Sign Up</a></li>
        <li><a href="#">Requests</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </div>



    <div class="login">
      <form action="login.php" method="POST">
        <table>
      <tr>
            <td>
               <b>Username/ID :</b>
            </td>
            <td>
              <input type="number" name="username" placeholder="Username" required>
            </td>
        </tr>
        <tr>
            <td>
               <b>Password :</b>
            </td>
            <td>
              <input type="Password" name="password" placeholder="Password" required>
            </td>
 
            <td><input type="submit" name="login" value="Log In"></td>
 
          </tr>
          </table>
          </form>
    </div>
    <div>
        <form action="register.php" method="POST">
          <h1>Sign Up Here~></h1>
          <table>
         
          <tr>
            <td>
               <b>Name :</b>
            </td>
            <td>
              <input type="text" name="name" placeholder="Name" required>
            </td>
          </tr>
         
          <tr>
            <td>
               <b>NSU ID :</b>
            </td>
            <td>
              <input type="number" name="nsuid" placeholder="NSU ID NO" required>
            </td>
          </tr>
 
          <tr>
            <td>
               <b>Email :</b>
            </td>
            <td>
              <input type="email" name="email" placeholder="Email Address" required>
            </td>
          </tr>
 
          <tr>
            <td>
                <b>Gender :</b>
            </td>
            <td>
              <input type="radio" name="gender" value="Male">Male
              <input type="radio" name="gender" value="Female">Female
            </td>
          </tr>
 
          <tr>
            <td>
              <b>Department :</b>
            </td>
            <td>
              <select name="Department">
                <option selected hidden value=" ">Dept</option>
                <option value="Arch">ARCH</option>
                <option value="BBA">BBA</option>
                <option value="DBM">DBM</option>
                <option value="DMP">DMP</option>
                <option value="DPH">DPH</option>
                <option value="ECE">ECE</option>
                <option value="ENV">ENV</option>
                <option value="LAW">LAW</option>
                <option value="ENG">ENG</option>
                <option value="Pharma">Pharma</option>
              </select>
 
              <select name="Semester">
                <option selected hidden value=" ">Semester</option>
                <option value="1st">1st</option>
                <option value="2nd">2nd</option>
                <option value="3rd">3rd</option>
                <option value="4th">4th</option>
                <option value="5th">5th</option>
                <option value="6th">6th</option>
                <option value="7th">7th</option>
                <option value="8th">8th</option>
                <option value="9th">9th</option>
                <option value="10th">10th</option>
                <option value="11th">11th</option>
                <option value="12th">12th</option>
                <option value="13th">13th</option>
                <option value="14th">14th</option>
               
              </select>
 
            </td>
          </tr>
 
          <tr>
            <td>
               <b>Password :</b>
            </td>
            <td>
              <input type="password" name="password" placeholder="set Password" required>
            </td>
          </tr>
 
          <tr>
            <td><input type="submit" name="submit" onclick="alert('Congratulations..You have Registered Successfully :)')" value="Submit"></td>
          </tr>
         
        </table>
        </div>
      </form>
 
    </div>
   
</body>
</html>