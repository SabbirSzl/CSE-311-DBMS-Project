<?php
$name = $_POST['name'];
$id = $_POST['nsuid'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$dept = $_POST['Department'];
$smstr = $_POST['Semester'];
$pass = $_POST['password'];

$connection = new mysqli("localhost", "root", "", "dbms_project");
 $select = "SELECT nsuid FROM userinfo WHERE nsuid = ? limit 1";
 $insert = "INSERT INTO userinfo(name, nsuid, email, gender, Department, Semester, password) VALUES(?, ?, ?, ?, ?, ?, ?)";
 $stmt = $connection->prepare($select);
 $stmt->bind_param("i", $id);
 $stmt->execute();
 $stmt->bind_result($id);
 $stmt->store_result();
 $rnum = $stmt->num_rows;

  if($rnum==0)
  {
    $stmt->close();

    $stmt = $connection->prepare($insert);
  $stmt->bind_param("sisssss", $name, $id, $email, $gender, $dept, $smstr, $pass);
  $stmt->execute();
  echo "Registered Successfully!";

  }
  else
  {
    echo "Already Registered With this ID";
  }
  $stmt->close();
  $connection->close();


?>