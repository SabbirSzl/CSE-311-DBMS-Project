<?php
//include('session.php');
/*if(!isset($_SESSION['login_user']))
{
	header("location: DBMSProject.php");
}
*/
?>

<!DOCTYPE html>
<html>
<head>
	<title> Home Page </title>
</head>
<body>
	<div id="profile">
		<b id="welcome"> Welcome: User
		</b>
		<b id="logout"><a href="logout.php"></a></b>
	</div>
</body>
</html>