<?php

  $host = "localhost";
  $dbUsername = "root";
  $dbPassword = "";
  $dbname = "dbms_project";

  $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
?>