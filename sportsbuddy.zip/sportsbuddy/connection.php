<?php

  $host = "localhost";
  $dbUsername = "root";
  $dbPassword = "";
  $dbname = "sportsbuddy";

  $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
?>