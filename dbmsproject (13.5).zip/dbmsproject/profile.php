<?php
include('session.php');
if(!isset($_SESSION['login_user']))
{
	header("location: DBMSProject.php");
}

?>

<!DOCTYPE html>
<html>
<head>
	<title> Home Page </title>
	<style>
		
		body {background-color: DarkSlateGrey;}
		
		
  			  a
  			  {
  			  	margin-right: 20px;
  			  	color: white;
  			  }
  			 i
  			  {
  			  	margin-top: 40px;
  			  	color: #ffff00;
  			  	margin-left: 30px;
  			  	font-style: italic;
  			  	font-size: 40px;
  			  }
  			  #logout { 
 				margin-right: 40px;
 				margin-top: 40px;
 				width: 100px;
  				float: right;
  				padding: 5px ;
  			  }
	</style>
</head>
<body>
	<div id="profile">
		<b id="Welcome"><i> <?php echo $login_session; ?> </i></b>
		<b id="logout"><a href="logout.php">LOG OUT</a></b>
		<b id="profile"><a href="Home.php">Home</a></b>

		
		
	</div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="CSS/profile.css">
</head>
<body>
	<form action="Schedule_register.php" method="POST">

	<div class="wrapper">
		<div class="title">
			Choose your Interested Games to play!
		</div>
		
		<div class="container">
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="game[]" value="FOOTBALL" >
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">FOOTBALL</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="game[]" value="CRICKET">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">CRICKET</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="game[]" value="BASKETBALL">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">BASKETBALL</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="game[]" value="BADMINTON">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">BADMINTON</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="game[]" value="CHESS">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">CHESS</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="game[]" value="BILLIARD">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">BILLIARD</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="game[]" value="TABLE TENNIS">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">TABLE TENNIS</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="game[]" value="CAROM">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">CAROM</div>	
				</div>	
			</label>

			

		</div>
	</div>

	<div class="wrapper_timeslot">
		<div class="title">
			Select Your Free time slot's to Play!
		</div>

		<div class="container">
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="ts1" value="1st">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">09.00 AM - 10.00 AM</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="ts2" value="2nd">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">10.00 AM - 11.00 AM</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="ts3" value="3rd">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">11.00 AM - 12.00 AM</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="ts4" value="4th">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">12.00 AM - 01.00 PM</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="ts5" value="5th">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">01.00 PM - 02.00 PM</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="ts6" value="6th">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">02.00 PM - 03.00 PM</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="ts7" value="7th">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">03.00 PM - 04.00 PM</div>	
				</div>	
			</label>
			<label class="option_item">
				<input type="checkbox" class="checkbox" name="ts8" value="8th">
				<div class="option_inner">
					<div class="tickmark"></div>
					<div class="icon"></div>
					<div class="name">04.00 PM - 05.00 PM</div>	
				</div>	
			</label>


		</div>	
	</div>

	<div class="button">
		<input type="submit" name="submitf" onclick="alert('Congratulations..You have Submitted your schedule Successfully :)')" value="Submit The Schedule!!!">
	</div>
	</form>
	
</body>
</html>

