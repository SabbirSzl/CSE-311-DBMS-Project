<?php
include('session.php');
$connection = new mysqli("localhost", "root", "", "lasttry");
?>
<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="picture/logo.png">
<style>
*{
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 15px 17px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}


.column {
  float: left;
  width: 31%;
  padding: 10px;
  height: auto; 
}

.split:after {
  content: "";
  display: table;
  clear: both;
}
.box {
  box-sizing: border-box;
  border-style: dashed;
  width: 80%;
  margin-left: 20px;
  height: auto;
  border-radius: 10px;

  float:left; 
  margin-top: 55px;
  margin-bottom: 40px;
  background-color: lightblue;
  opacity: 0.8;
}
.header {
  background-color: #ffff00;
  padding: 0px;
  text-align: center;
  font-size: 10px;
}
select{
        width: 150px;
        margin: 5px;
    }
input{
  width: 150px;
        margin: 5px;
}

.footer{
  background-color: #f1f1f1;
  padding: 0;
  text-align: center;
}
#fetch_data{
  box-sizing: border-box;
  margin-right: 5px;
  margin-top: 30px;
}
#myInput {

  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 80%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
</head>
<body>

<div class="topnav">
  <a href="home.php">
    <img src="logo.png"  style="width:92px;height: 25px;">
  </a>
  <a class="active" href="Home.php">Home</a>
  <a href="profilepage.php">Profile</a>
  <a href="DBMSProject.php">Sign Up</a>
  <a href="dashboard.php">Contact</a>
  <a href="#about">About</a>
</div>



<div class="split">
  <div class="column" style="background-color:#aaa;">
    
  </div>
  <div class="column" style="background-color:#bbb;">
    
  </div>
  <div class="column" style="background-color:#fff;">
    <div class="box">
      <div class="header">
        <h2>Simple Search</h2>
      </div>
        <div class="row" >
          <form action="Home.php" method="POST">
  
            <tr>
              <td>
                <b>Sports :</b>
              </td>
              <td>
              <select name="sports">
                <option selected hidden value=" ">Sports</option>
                <option value="CRICKET">CRICKET</option>
                <option value="FOOTBALL">FOOTBALL</option>
                <option value="BASKETBALL">BASKETBALL</option>
                <option value="BADMINTON">BADMINTON</option>
                <option value="CHESS">CHESS</option>
                <option value="BILLIARD">BILLIARD</option>
                <option value="TABLE TENNIS">TABLE TENNIS</option>
                <option value="CAROM">CAROM</option>
              </select>
 
              
 
              </td>

           
          </tr>
          <br>

          <tr>
            <td>
              <b>Times :</b>
            </td>
            <td>
              <select name="times" >
                <option selected hidden value=" ">Times</option>
                <option value="09:00:00">09:00:00</option>
                <option value="10:00:00">10:00:00</option>
                <option value="11:00:00">11:00:00</option>
                <option value="12:00:00">12:00:00</option>
                <option value="13:00:00">13:00:00</option>
                <option value="14:00:00">14:00:00</option>
                <option value="15:00:00">15:00:00</option>
                <option value="16:00:00">16:00:00</option>
                <option value="17:00:00">17:00:00</option>
              </select>
 
              
 
            </td>

           
          </tr>
          <br>
          <tr>
            <td>
              <b>Dates   :</b>
            </td>
            <td>
              <input type="date" id="myDate" name="date" value="Date">
            </td>

           
          </tr>
          






<div class="footer">
   <input type="submit" name="search" value="Search Buddies">

</div>
</form>
</div>
</div>

<div class="fetch_data">
  <h2> Matched Buddies</h2>
  <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name">

<table id="myTable">
  <tr class="header">
    <th style="width:40%;">Name</th>
    <th style="width:60%;">Email</th>
  </tr>
  <?php




if(isset($_POST['search']))
{
  $u_index = $_SESSION['login_user']; 
  $sport = $_POST['sports'];
  $time = $_POST['times'];
  $date = $_POST['date'];

  $query= "SELECT name,email FROM user u join selected_timeslot t on u.nsuid=t.user_id
  JOIN game g ON t.user_id=g.user_id WHERE g.game='$sport' AND t.s_date = '$date' 
    AND t.s_time ='$time'";
  $result = mysqli_query($connection,$query);
  


    while($row = mysqli_fetch_assoc($result)){ 
  ?>
  <tr>
    <td><?= $row['name']; ?></td>
    <td><?= $row['email']; ?></td>
    
    
  </tr>
  <?php
  }} ?>

 
  
</table>
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</div>
</div>
</div>
</body>
</html>