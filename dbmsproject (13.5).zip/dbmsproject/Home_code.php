<?php
include('session.php');
$connection = new mysqli("localhost", "root", "", "lasttry");

$u_index = $_SESSION['login_user']; 
$sport = $_POST['sports'];
$time = $_POST['times'];
$date = $_POST['date'];



if(isset($_POST['search']))
{
  $query= "SELECT name,email FROM user u join selected_timeslot t on u.nsuid=t.user_id
  JOIN game g ON t.user_id=g.user_id WHERE g.game='$sport' AND t.s_date = '$date' 
    AND t.s_time ='$time'";
  $result = mysqli_query($connection,$query);
  //header("location: Home.php");
}
