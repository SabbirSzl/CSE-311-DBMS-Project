<!DOCTYPE html>
<html>
<head>
	<title>Registration Denied</title>
	<style type="text/css">
		.box{
			box-sizing: border-box;
			
	width: 80%;
	height: auto;
	border-radius: 20px;
	padding: 30px;

	text-align: center; 
	margin-top: 25px;
	margin-right: 50px;
  margin-left: 100px;
	background-color: lightblue;
}
		button{
  width: 80%;
  box-sizing: border-box;
  padding: 10px 3px;
  margin-top: 20px;
  margin-right: 50px;
  margin-left: 100px;
  outline: none;
  border: none;
  background: #60adde;
  opacity: 0.8;
  border-radius: 10px;
  font-size: 16px;
  color: #fff;
}
button:hover{
 background: #003366;
  opacity: 0.8;  
}
	</style>
</head>
<body>
	<div class="box">
		<h2>This ID No is Already Registered.</h2> 
	</div>
	<div class="button">
		<a href="DBMSProject.php"><button>Create An Account</button></a>
		<a href="DBMSProject.php"><button>Already have an account</button></a>

	</div>
</body>
</html>