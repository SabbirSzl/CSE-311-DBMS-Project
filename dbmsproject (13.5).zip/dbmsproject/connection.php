<?php

  $host = "localhost";
  $dbUsername = "root";
  $dbPassword = "";
  $dbname = "lasttry";

  $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
?>